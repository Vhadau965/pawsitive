package com.example.pawsitivepetacademy;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.text.InputType;
import android.view.View;
import android.widget.*;

import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {

    private LinearLayout contentLayout;
    private Spinner navigationSpinner;

    // Course class
    static class Course {

        String name;
        double fee;
        String purpose;
        String[] content;

        Course(String name, double fee, String purpose, String[] content) {
            this.name = name;
            this.fee = fee;
            this.purpose = purpose;
            this.content = content;
        }
    }

    // Course list
    private final ArrayList<Course> courses = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        contentLayout = findViewById(R.id.contentLayout);
        navigationSpinner = findViewById(R.id.navigationSpinner);

        createCourses();
        setupNavigation();

        showHome();
    }

    // ---------------------------------------------------------
    // CREATE COURSES
    // ---------------------------------------------------------

    private void createCourses() {

        courses.add(new Course(
                "Canine Obedience Training",
                1500,
                "To teach effective dog obedience and behavioural training techniques.",
                new String[]{
                        "Basic commands",
                        "Leash training",
                        "Behaviour correction",
                        "Positive reinforcement",
                        "Socialisation techniques"
                }
        ));

        courses.add(new Course(
                "Pet Grooming",
                1500,
                "To provide professional grooming skills for domestic pets.",
                new String[]{
                        "Coat care",
                        "Bathing techniques",
                        "Nail trimming",
                        "Ear and eye cleaning",
                        "Grooming equipment"
                }
        ));

        courses.add(new Course(
                "Animal Behaviour",
                1500,
                "To understand common pet behaviours and improve communication with animals.",
                new String[]{
                        "Animal psychology",
                        "Reading body language",
                        "Stress management",
                        "Behaviour modification",
                        "Enrichment activities"
                }
        ));

        courses.add(new Course(
                "Pet Business Management",
                1500,
                "To prepare learners to operate a successful pet-related business.",
                new String[]{
                        "Customer service",
                        "Marketing",
                        "Business planning",
                        "Financial management",
                        "Legal requirements"
                }
        ));

        courses.add(new Course(
                "Puppy Care",
                750,
                "To provide new puppy owners with essential care knowledge.",
                new String[]{
                        "Feeding",
                        "Vaccinations",
                        "Toilet training",
                        "Exercise",
                        "Socialisation"
                }
        ));

        courses.add(new Course(
                "Pet First Aid",
                750,
                "To provide emergency first aid knowledge for pets.",
                new String[]{
                        "Minor injuries",
                        "CPR basics",
                        "Poison awareness",
                        "Heatstroke",
                        "Emergency transport"
                }
        ));

        courses.add(new Course(
                "Basic Dog Walking",
                750,
                "To teach safe and professional dog walking practices.",
                new String[]{
                        "Walking equipment",
                        "Handling multiple dogs",
                        "Safety procedures",
                        "Exercise routines"
                }
        ));
    }

    // ---------------------------------------------------------
    // NAVIGATION
    // ---------------------------------------------------------

    private void setupNavigation() {

        String[] menuItems = {

                "Home",
                "About Us",
                "Six-Month Programmes",
                "Six-Week Short Courses",
                "Calculate Total Fees",
                "Contact Details"

        };

        ArrayAdapter<String> adapter =
                new ArrayAdapter<>(
                        this,
                        android.R.layout.simple_spinner_dropdown_item,
                        menuItems
                );

        navigationSpinner.setAdapter(adapter);

        navigationSpinner.setOnItemSelectedListener(
                new AdapterView.OnItemSelectedListener() {

                    @Override
                    public void onItemSelected(
                            AdapterView<?> parent,
                            View view,
                            int position,
                            long id) {

                        switch (position) {

                            case 0:
                                showHome();
                                break;

                            case 1:
                                showAbout();
                                break;

                            case 2:
                                showLongCourses();
                                break;

                            case 3:
                                showShortCourses();
                                break;

                            case 4:
                                showCalculator();
                                break;

                            case 5:
                                showContact();
                                break;
                        }
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {
                    }
                }
        );
    }

    // ---------------------------------------------------------
    // CLEAR SCREEN
    // ---------------------------------------------------------

    private void clearScreen() {

        contentLayout.removeAllViews();
    }

    // ---------------------------------------------------------
    // TEXT VIEW
    // ---------------------------------------------------------

    private TextView createText(
            String text,
            float size,
            boolean bold) {

        TextView textView = new TextView(this);

        textView.setText(text);
        textView.setTextSize(size);
        textView.setTextColor(Color.rgb(38, 50, 56));

        textView.setTypeface(null, bold ? Typeface.BOLD : Typeface.NORMAL);

        textView.setPadding(0, 10, 0, 10);

        return textView;
    }

    // ---------------------------------------------------------
    // BUTTON
    // ---------------------------------------------------------

    private Button createButton(
            String text,
            View.OnClickListener listener) {

        Button button = new Button(this);

        button.setText(text);
        button.setOnClickListener(listener);

        return button;
    }

    // ---------------------------------------------------------
    // HOME
    // ---------------------------------------------------------

    private void showHome() {

        clearScreen();

        contentLayout.addView(
                createText(
                        "Welcome to Pawsitive Pet Academy",
                        24,
                        true
                )
        );

        contentLayout.addView(
                createText(
                        "🐶 Caring • Trustworthy • Professional",
                        17,
                        true
                )
        );

        contentLayout.addView(
                createText(
                        "Pawsitive Pet Academy is a Durban-based pet care "
                                + "education provider established in 2023 by Sarah Smith.\n\n"
                                + "We provide practical training for pet owners, "
                                + "aspiring pet-care professionals and animal lovers.\n\n"
                                + "Our courses focus on pet care, animal training, "
                                + "first aid, grooming, behaviour and pet business skills.",
                        16,
                        false
                )
        );

        contentLayout.addView(
                createButton(
                        "View Professional Programmes",
                        v -> showLongCourses()
                )
        );

        contentLayout.addView(
                createButton(
                        "View Short Courses",
                        v -> showShortCourses()
                )
        );

        contentLayout.addView(
                createButton(
                        "Calculate Total Fees",
                        v -> showCalculator()
                )
        );
    }

    // ---------------------------------------------------------
    // ABOUT US
    // ---------------------------------------------------------

    private void showAbout() {

        clearScreen();

        contentLayout.addView(
                createText(
                        "About Pawsitive Pet Academy",
                        24,
                        true
                )
        );

        contentLayout.addView(
                createText(
                        "Our History",
                        20,
                        true
                )
        );

        contentLayout.addView(
                createText(
                        "Pawsitive Pet Academy was established in 2023 "
                                + "by Sarah Smith in Durban. The academy was created "
                                + "because many pet owners had limited knowledge "
                                + "about proper pet care, training, nutrition and emergency care.\n\n"
                                + "Hundreds of pet owners and aspiring pet-care "
                                + "professionals have completed our programmes.",
                        16,
                        false
                )
        );

        contentLayout.addView(
                createText(
                        "Our Vision",
                        20,
                        true
                )
        );

        contentLayout.addView(
                createText(
                        "To become a trusted pet-care education provider "
                                + "that improves animal wellbeing and creates "
                                + "opportunities in the pet-care industry.",
                        16,
                        false
                )
        );

        contentLayout.addView(
                createText(
                        "Our Mission",
                        20,
                        true
                )
        );

        contentLayout.addView(
                createText(
                        "To provide accessible, practical and professional "
                                + "training that equips people with knowledge "
                                + "and confidence to care for animals responsibly.",
                        16,
                        false
                )
        );

        contentLayout.addView(
                createText(
                        "Our Goals",
                        20,
                        true
                )
        );

        contentLayout.addView(
                createText(
                        "• Promote responsible pet ownership\n"
                                + "• Improve animal wellbeing\n"
                                + "• Develop employable pet-care skills\n"
                                + "• Support aspiring pet-care entrepreneurs\n"
                                + "• Expand practical animal training",
                        16,
                        false
                )
        );
    }

    // ---------------------------------------------------------
    // SIX-MONTH COURSES
    // ---------------------------------------------------------

    private void showLongCourses() {

        clearScreen();

        contentLayout.addView(
                createText(
                        "Six-Month Professional Programmes",
                        24,
                        true
                )
        );

        contentLayout.addView(
                createText(
                        "The academy offers four professional development "
                                + "programmes. The scenario specifies six-month "
                                + "programmes delivered over 12 weeks.",
                        16,
                        false
                )
        );

        for (int i = 0; i < 4; i++) {

            Course course = courses.get(i);

            addCourseCard(course);
        }
    }

    // ---------------------------------------------------------
    // SHORT COURSES
    // ---------------------------------------------------------

    private void showShortCourses() {

        clearScreen();

        contentLayout.addView(
                createText(
                        "Six-Week Practical Skills Courses",
                        24,
                        true
                )
        );

        contentLayout.addView(
                createText(
                        "These short courses focus on practical pet-care skills "
                                + "and are designed to be completed over six weeks.",
                        16,
                        false
                )
        );

        for (int i = 4; i < courses.size(); i++) {

            Course course = courses.get(i);

            addCourseCard(course);
        }
    }

    // ---------------------------------------------------------
    // COURSE CARD
    // ---------------------------------------------------------

    private void addCourseCard(Course course) {

        LinearLayout card = new LinearLayout(this);

        card.setOrientation(LinearLayout.VERTICAL);

        card.setPadding(10, 15, 10, 15);

        TextView title =
                createText(
                        "🐾 " + course.name,
                        19,
                        true
                );

        TextView purpose =
                createText(
                        course.purpose,
                        15,
                        false
                );

        TextView fee =
                createText(
                        "Course Fee: R"
                                + String.format(
                                Locale.US,
                                "%.2f",
                                course.fee
                        ),
                        17,
                        true
                );

        Button details =
                createButton(
                        "View Course Details",
                        v -> showCourseDetails(course)
                );

        card.addView(title);
        card.addView(purpose);
        card.addView(fee);
        card.addView(details);

        contentLayout.addView(card);
    }

    // ---------------------------------------------------------
    // COURSE DETAILS
    // ---------------------------------------------------------

    private void showCourseDetails(Course course) {

        clearScreen();

        contentLayout.addView(
                createText(
                        "🐾 " + course.name,
                        24,
                        true
                )
        );

        contentLayout.addView(
                createText(
                        "Course Fee: R"
                                + String.format(
                                Locale.US,
                                "%.2f",
                                course.fee
                        ),
                        19,
                        true
                )
        );

        contentLayout.addView(
                createText(
                        "Purpose",
                        20,
                        true
                )
        );

        contentLayout.addView(
                createText(
                        course.purpose,
                        16,
                        false
                )
        );

        contentLayout.addView(
                createText(
                        "Course Content",
                        20,
                        true
                )
        );

        StringBuilder content = new StringBuilder();

        for (String item : course.content) {

            content.append("• ")
                    .append(item)
                    .append("\n");
        }

        contentLayout.addView(
                createText(
                        content.toString(),
                        16,
                        false
                )
        );

        contentLayout.addView(
                createButton(
                        "Select This Course",
                        v -> showCalculator()
                )
        );
    }

    // ---------------------------------------------------------
    // CALCULATOR
    // ---------------------------------------------------------

    private void showCalculator() {

        clearScreen();

        contentLayout.addView(
                createText(
                        "Calculate Total Fees",
                        24,
                        true
                )
        );

        contentLayout.addView(
                createText(
                        "Select one or more courses. "
                                + "The discount will automatically be applied.",
                        16,
                        false
                )
        );

        EditText name =
                new EditText(this);

        name.setHint("Full Name");

        contentLayout.addView(name);

        EditText phone =
                new EditText(this);

        phone.setHint("Phone Number");

        phone.setInputType(
                InputType.TYPE_CLASS_PHONE
        );

        contentLayout.addView(phone);

        EditText email =
                new EditText(this);

        email.setHint("Email Address");

        email.setInputType(
                InputType.TYPE_CLASS_TEXT
                        | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
        );

        contentLayout.addView(email);

        contentLayout.addView(
                createText(
                        "Select Courses",
                        19,
                        true
                )
        );

        ArrayList<CheckBox> checkBoxes =
                new ArrayList<>();

        for (Course course : courses) {

            CheckBox checkBox =
                    new CheckBox(this);

            checkBox.setText(
                    course.name
                            + " - R"
                            + String.format(
                            Locale.US,
                            "%.2f",
                            course.fee
                    )
            );

            checkBoxes.add(checkBox);

            contentLayout.addView(checkBox);
        }

        TextView result =
                createText(
                        "",
                        16,
                        false
                );

        contentLayout.addView(result);

        Button calculate =
                createButton(
                        "Calculate Quote",
                        v -> {

                            // -------------------------
                            // VALIDATE NAME
                            // -------------------------

                            String customerName =
                                    name.getText()
                                            .toString()
                                            .trim();

                            if (customerName.isEmpty()) {

                                name.setError(
                                        "Please enter your name"
                                );

                                name.requestFocus();

                                return;
                            }

                            // -------------------------
                            // VALIDATE PHONE
                            // -------------------------

                            String customerPhone =
                                    phone.getText()
                                            .toString()
                                            .trim();

                            if (!customerPhone.matches(
                                    "0\\d{9}"
                            )) {

                                phone.setError(
                                        "Enter a valid 10-digit phone number"
                                );

                                phone.requestFocus();

                                return;
                            }

                            // -------------------------
                            // VALIDATE EMAIL
                            // -------------------------

                            String customerEmail =
                                    email.getText()
                                            .toString()
                                            .trim();

                            if (!customerEmail.matches(
                                    "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$"
                            )) {

                                email.setError(
                                        "Enter a valid email address"
                                );

                                email.requestFocus();

                                return;
                            }

                            // -------------------------
                            // SELECTED COURSES ARRAY
                            // -------------------------

                            ArrayList<Course> selectedCourses =
                                    new ArrayList<>();

                            for (int i = 0;
                                 i < checkBoxes.size();
                                 i++) {

                                if (checkBoxes
                                        .get(i)
                                        .isChecked()) {

                                    selectedCourses.add(
                                            courses.get(i)
                                    );
                                }
                            }

                            if (selectedCourses.isEmpty()) {

                                Toast.makeText(
                                        MainActivity.this,
                                        "Please select at least one course",
                                        Toast.LENGTH_SHORT
                                ).show();

                                return;
                            }

                            // -------------------------
                            // CALCULATE SUBTOTAL
                            // -------------------------

                            double subtotal = 0;

                            for (Course course :
                                    selectedCourses) {

                                subtotal += course.fee;
                            }

                            // -------------------------
                            // DISCOUNT
                            // -------------------------

                            double discountRate;

                            int numberOfCourses =
                                    selectedCourses.size();

                            if (numberOfCourses == 1) {

                                discountRate = 0;

                            } else if (numberOfCourses == 2) {

                                discountRate = 0.05;

                            } else if (numberOfCourses == 3) {

                                discountRate = 0.10;

                            } else {

                                discountRate = 0.15;
                            }

                            double discount =
                                    subtotal * discountRate;

                            double amountAfterDiscount =
                                    subtotal - discount;

                            // -------------------------
                            // VAT
                            // -------------------------

                            double vat =
                                    amountAfterDiscount * 0.15;

                            // -------------------------
                            // TOTAL
                            // -------------------------

                            double total =
                                    amountAfterDiscount + vat;

                            // -------------------------
                            // ARRAY OUTPUT
                            // -------------------------

                            StringBuilder selected =
                                    new StringBuilder();

                            for (Course course :
                                    selectedCourses) {

                                selected.append(
                                        "• "
                                                + course.name
                                                + "\n"
                                );
                            }

                            // -------------------------
                            // DISPLAY QUOTE
                            // -------------------------

                            String quote =
                                    "CUSTOMER DETAILS\n\n"
                                            + "Name: "
                                            + customerName
                                            + "\n"
                                            + "Phone: "
                                            + customerPhone
                                            + "\n"
                                            + "Email: "
                                            + customerEmail
                                            + "\n\n"

                                            + "SELECTED COURSES\n"
                                            + selected
                                            + "\n"

                                            + "Subtotal: R"
                                            + String.format(
                                            Locale.US,
                                            "%.2f",
                                            subtotal
                                    )

                                            + "\nDiscount ("
                                            + (int)
                                            (discountRate * 100)
                                            + "%): -R"
                                            + String.format(
                                            Locale.US,
                                            "%.2f",
                                            discount
                                    )

                                            + "\nVAT (15%): R"
                                            + String.format(
                                            Locale.US,
                                            "%.2f",
                                            vat
                                    )

                                            + "\n\nTOTAL QUOTED FEE: R"
                                            + String.format(
                                            Locale.US,
                                            "%.2f",
                                            total
                                    )

                                            + "\n\nThis is a quoted fee only "
                                            + "and is not a formal invoice.";

                            result.setText(quote);
                        }
                );

        contentLayout.addView(calculate);
    }

    // ---------------------------------------------------------
    // CONTACT
    // ---------------------------------------------------------

    private void showContact() {

        clearScreen();

        contentLayout.addView(
                createText(
                        "Contact Pawsitive Pet Academy",
                        24,
                        true
                )
        );

        contentLayout.addView(
                createText(
                        "📞 Phone\n"
                                + "031 555 2023\n\n"
                                + "✉ Email\n"
                                + "info@pawsitivepetacademy.co.za\n\n"
                                + "📱 Social Media\n"
                                + "Facebook | Instagram | TikTok\n\n"
                                + "📍 Physical Address\n"
                                + "Durban Training Centre\n"
                                + "Durban, KwaZulu-Natal\n"
                                + "South Africa\n\n"
                                + "🗺 Directions\n"
                                + "Use Google Maps to navigate to "
                                + "Durban, KwaZulu-Natal.",
                        16,
                        false
                )
        );

        contentLayout.addView(
                createButton(
                        "Open Google Maps",
                        v -> {

                            android.content.Intent intent =
                                    new android.content.Intent(
                                            android.content.Intent.ACTION_VIEW,
                                            android.net.Uri.parse(
                                                    "geo:0,0?q=Durban,+KwaZulu-Natal"
                                            )
                                    );

                            startActivity(intent);
                        }
                )
        );
    }
}
